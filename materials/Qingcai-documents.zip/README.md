# 青财 · 当前参赛文档

入口：[参赛材料](docs/competition/README.md)。

完整源码、模型、PPT 与 PDF 见 https://github.com/gr-peng/gonghang 。本包不包含运行凭据或私人账本。
