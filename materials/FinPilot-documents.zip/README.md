# FinPilot · 财富管理服务参赛材料

先阅读 [赛道适配评估](docs/competition/ICBC-WEALTH.md)，再查看 [材料入口](docs/competition/README.md)。

完整源码、模型与答辩材料：https://github.com/gr-peng/gonghang
